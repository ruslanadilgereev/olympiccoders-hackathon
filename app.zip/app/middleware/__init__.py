"""Middleware modules for the design automation agent."""
from app.middleware.image_extractor import extract_images_from_state


