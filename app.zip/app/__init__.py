"""Hackathon Agent package."""

